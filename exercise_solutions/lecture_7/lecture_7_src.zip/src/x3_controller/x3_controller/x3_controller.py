import time
import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action.server import ServerGoalHandle

from rclpy.executors import MultiThreadedExecutor

from geometry_msgs.msg import Vector3
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Point

from nav_msgs.msg import Odometry


from x3_interfaces.action import X3Command



# This variable is used for the drone to stay away from the ground
# Now that our movement also makes the drone fly up if necessary, the
# fly_to_altitude function should only be used to compensate if the drone is
# too close to the ground.
# This movement is necessary because rotors behave differently when close
# to the ground, so it is wise to always lift the drone up a little bit
# before doing any further movement.
DRONE_MIN_ALTITUDE_TO_PERFORM_MOVEMENT = 1


class X3Controller(Node):

    def __init__(self):
        super().__init__('x3_controller')

        self.position = Point(x=0.0, y=0.0, z=0.0)
        self.yaw = 0

        self.cmd_vel_topic = self.create_publisher(
            Twist,
            'X3/cmd_vel',
            10
        )

        self.odometry_topic = self.create_subscription(
            Odometry,
            'X3/odometry',
            self.store_position_callback,
            10
        )

        self.move_action = ActionServer(
            self,
            X3Command,
            'X3/fly_up',
            self.action_callback
        )


    def action_callback(self, msg : ServerGoalHandle):

        # By specifying the type of the request, you can have the autocomplete of
        # your interface variable working.
        # Always remember to use "ros2 interface show ..." when in doubt!
        command_goal : X3Command.Goal = msg.request

        self.get_logger().info("Action requested. Performing movement to target:")
        self.get_logger().info(str(command_goal.target))

        self.fly_to_altitude(DRONE_MIN_ALTITUDE_TO_PERFORM_MOVEMENT)
        
        self.get_logger().info("Altitute reached, now rotating...")
        self.rotate_to_target(command_goal.target)

        self.get_logger().info("Rotated to target. Now moving towards it...")
        self.move_to_target(command_goal.target)

        self.get_logger().info("Movement completed, setting goal succedeed and completing action!")
        msg.succeed()

        result =  X3Command.Result()
        result.success="Movement completed"

        return result


    def store_position_callback(self, msg : Odometry):

        self.position = msg.pose.pose.position
        self.yaw = get_yaw(
            msg.pose.pose.orientation.x,
            msg.pose.pose.orientation.y,
            msg.pose.pose.orientation.z,
            msg.pose.pose.orientation.w
        )


    def fly_to_altitude(self, altitude):

        # Instantiate the move_up message
        move_up = Twist()
        move_up.linear = Vector3(x=0.0, y=0.0, z=1.0)
        move_up.angular = Vector3(x=0.0, y=0.0, z=0.0)

        self.cmd_vel_topic.publish(move_up)

        # Wait for the drone to reach the desired altitude
        # Note that in order for the drone to be perfectly aligned with the
        # requested height (not required for the exercise), you should keep on
        # listening to the current position and reduce the linear speed when 
        # you get close to the desired altitude
        while(self.position.z < altitude):
            time.sleep(0.1)

        # Stop movement after the altitue has been reached
        stop_mov = Twist()
        stop_mov.linear = Vector3(x=0.0, y=0.0, z=0.0)
        stop_mov.angular = Vector3(x=0.0, y=0.0, z=0.0)
        self.cmd_vel_topic.publish(stop_mov)

    def rotate_to_target(self, target, eps = 0.2):

        target = (target.x, target.y, target.z)

        # We compute the angle between the current target position and the target
        # position here

        start_position = (self.position.x, self.position.y)
        target_angle = angle_between_points(start_position, target)
        angle_to_rotate = target_angle - self.yaw

        # We verify the optimal direction of the rotation here
        rotation_dir = -1
        if angle_to_rotate < 0 or angle_to_rotate > math.pi:
            rotation_dir = 1
        
        
        # Prepare the cmd_vel message
        move_msg = Twist()
        move_msg.linear = Vector3(x=0.0, y=0.0, z=0.0)
        move_msg.angular = Vector3(x=0.0, y=0.0, z = 0.5 * rotation_dir)
        self.cmd_vel_topic.publish(move_msg)

        # Publish the message until the correct rotation is reached (accounting for some eps error)
        # Note that here the eps also helps us stop the drone and not overshoot the target, as
        # the drone will keep moving for a while after it receives a stop message
        # Also note that rotating the drone too fast will make it loose altitude.
        # You can account for that by also giving some z linear speed to the rotation movement.
        while abs(angle_to_rotate) > eps:
            angle_to_rotate = target_angle - self.yaw
            # No sleep here. We don't want to miss the angle by sleeping too much. Even 0.1 seconds
            # could make us miss the given epsilon interval

        # When done, send a stop message to be sure that the drone doesn't
        # overshoot its target
        stop_msg = Twist()
        stop_msg.linear = Vector3(x=0.0, y=0.0, z=0.0)
        stop_msg.angular = Vector3(x=0.0, y=0.0, z=0.0)
        self.cmd_vel_topic.publish(stop_msg)

    def move_to_target(self, target : Point, eps = 0.5):

        current_position = (self.position.x, self.position.y, self.position.z)
        objective_point = (target.x, target.y, target.z)

        #print(point_distance(objective_point, current_position))

        while point_distance(current_position, objective_point) > eps:

            current_position = (self.position.x, self.position.y, self.position.z)
            direction_vector = move_vector(current_position, objective_point)

            print(direction_vector)

            mov = Twist()
            mov.linear = Vector3(x=direction_vector[0], y=0.0, z=direction_vector[1])
            mov.angular = Vector3(x=0.0, y=0.0, z=0.0)

            angle = angle_between_points(current_position, objective_point)
            current_angle = self.yaw

            if not (angle-0.05 < current_angle < angle+0.05):
                angle_diff = (current_angle-angle)
                mov.angular = Vector3(x=0.0, y=0.0, z=math.sin(angle_diff))

            self.cmd_vel_topic.publish(mov)

        stop_mov = Twist()
        stop_mov.linear = Vector3(x=0.0, y=0.0, z=0.0)
        stop_mov.angular = Vector3(x=0.0, y=0.0, z=0.0)

        self.movement_complete = True
        self.cmd_vel_topic.publish(stop_mov)


        
def angle_between_points(p0 : tuple, p1 : tuple):

    '''
    Computes the angle between the two given points, in radiants.
    p0: the coordinates of the first point (x0, y0)
    p1: the coordinates of the second point (x1, y1)
    '''

    vector_between = (p1[0] - p0[0], p1[1] - p0[1])

    norm = math.sqrt(vector_between[0] ** 2 + vector_between[1] ** 2)
    direction = (vector_between[0] / norm, vector_between[1] / norm)

    return math.atan2(direction[0], direction[1])

def point_distance(p0, p1):

	'''
    Computes the distance between the two given points.
    p0: the coordinates of the first point (x0, y0)
    p1: the coordinates of the second point (x1, y1)
    '''

	vb = (p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2])
	return math.sqrt(vb[0]**2 + vb[1]**2 + vb[2]**2)


def move_vector(p0 : tuple, p1 : tuple):

	'''
    Computes the unit vector between the two given points on a 2d plane.
    The vector is calculated on a 2d plane perpendicular to the ground_plane
    and passing between p0 and p1.
    The x and y components are merged into a single, forward, component.
    Direction of the vector is from p0 to p1.
    p0: the coordinates of the first point (x0, y0, z0)
    p1: the coordinates of the second point (x1, y1, z1)
    '''
	vb = (math.sqrt( (p1[0] - p0[0])**2 + (p1[1] - p0[1])**2), p1[2] - p0[2])
	norm = math.sqrt(vb[0]**2 + vb[1]**2)

	return (vb[0] / norm, vb[1] / norm)


def euler_from_quaternion(x, y, z, w):
    
    """
    Convert a quaternion into euler angles (roll, pitch, yaw)
    roll is rotation around x in radians (counterclockwise)
    pitch is rotation around y in radians (counterclockwise)
    yaw is rotation around z in radians (counterclockwise)
    """

    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll_x = math.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch_y = math.asin(t2)

    t3 = +1.0 - 2.0 * (y * y + z * z)
    t4 = +2.0 * (w * z + x * y)
    yaw_z = math.atan2(t3, t4)

    return roll_x, pitch_y, yaw_z # in radians


def get_yaw(x, y, z, w):
    return euler_from_quaternion(x,y,z,w)[2]

def main():

    rclpy.init()
    
    x3_controller = X3Controller()
    
    executor = MultiThreadedExecutor()
    executor.add_node(x3_controller)

    executor.spin()

    executor.shutdown()
    x3_controller.destroy_node()

    rclpy.shutdown()