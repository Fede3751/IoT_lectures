import time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer

from rclpy.executors import MultiThreadedExecutor

from geometry_msgs.msg import Vector3
from geometry_msgs.msg import Twist

from nav_msgs.msg import Odometry


from x3_interfaces.action import X3Command



class X3Controller(Node):

    def __init__(self):
        super().__init__('x3_controller')

        self.position = None

        self.cmd_vel_topic = self.create_publisher(
            Twist,
            'X3/cmd_vel',
            10
        )

        self.odometry_topic = self.create_subscription(
            Odometry,
            'X3/odometry',
            self.store_position_callback,
            10
        )

        self.nove_action = ActionServer(
            self,
            X3Command,
            'X3/fly_up',
            self.fly_to_altitude
        )

    def store_position_callback(self, msg : Odometry):

        self.position = msg.pose.pose.position
        #self.get_logger().info(str(self.position))


    def fly_to_altitude(self, msg):

        altitude = msg.request.altitude

        move_up = Twist()
        move_up.linear = Vector3(x=0.0, y=0.0, z=1.0)
        move_up.angular = Vector3(x=0.0, y=0.0, z=0.0)


        self.cmd_vel_topic.publish(move_up)

        while(self.position.z < altitude):
            time.sleep(0.1)

        stop_mov = Twist()

        stop_mov.linear = Vector3(x=0.0, y=0.0, z=0.0)
        stop_mov.angular = Vector3(x=0.0, y=0.0, z=0.0)

        self.cmd_vel_topic.publish(stop_mov)

    



def main():

    rclpy.init()
    
    x3_controller = X3Controller()
    
    executor = MultiThreadedExecutor()
    executor.add_node(x3_controller)

    executor.spin()

    executor.shutdown()
    x3_controller.destroy_node()

    rclpy.shutdown()